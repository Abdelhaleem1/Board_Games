var files_dup =
[
    [ "BoardGame_Classes.h", "_board_game___classes_8h_source.html", null ],
    [ "connect4.h", "connect4_8h_source.html", null ],
    [ "Diamond_TicTacToe.h", "_diamond___tic_tac_toe_8h_source.html", null ],
    [ "Diamond_UI.h", "_diamond___u_i_8h.html", "_diamond___u_i_8h" ],
    [ "Inf_TicTacToe.h", "_inf___tic_tac_toe_8h.html", "_inf___tic_tac_toe_8h" ],
    [ "Inverse_TicTacToe.h", "_inverse___tic_tac_toe_8h_source.html", null ],
    [ "Inverse_XO_UI.h", "_inverse___x_o___u_i_8h.html", "_inverse___x_o___u_i_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Memory.h", "_memory_8h_source.html", null ],
    [ "NUMERICAL_TIC_TAC_TOE.h", "_n_u_m_e_r_i_c_a_l___t_i_c___t_a_c___t_o_e_8h.html", "_n_u_m_e_r_i_c_a_l___t_i_c___t_a_c___t_o_e_8h" ],
    [ "obs_TicTacToe.h", "obs___tic_tac_toe_8h.html", "obs___tic_tac_toe_8h" ],
    [ "Pyramid_Tic_Tac_Toe.h", "_pyramid___tic___tac___toe_8h.html", "_pyramid___tic___tac___toe_8h" ],
    [ "SUS.h", "_s_u_s_8h.html", "_s_u_s_8h" ],
    [ "TIC_TAC_TOE_4X4.h", "_t_i_c___t_a_c___t_o_e__4_x4_8h.html", "_t_i_c___t_a_c___t_o_e__4_x4_8h" ],
    [ "TicTacToe_5x5.h", "_tic_tac_toe__5x5_8h.html", "_tic_tac_toe__5x5_8h" ],
    [ "Ultimate_TicTacToe.h", "_ultimate___tic_tac_toe_8h_source.html", null ],
    [ "Ultimate_UI.h", "_ultimate___u_i_8h.html", "_ultimate___u_i_8h" ],
    [ "Word_TicTacToe.h", "_word___tic_tac_toe_8h.html", "_word___tic_tac_toe_8h" ]
];