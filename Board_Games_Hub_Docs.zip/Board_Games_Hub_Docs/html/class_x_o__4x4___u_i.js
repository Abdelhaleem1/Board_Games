var class_x_o__4x4___u_i =
[
    [ "XO_4x4_UI", "class_x_o__4x4___u_i.html#ab9061a7ca8ebe5d55fb9f86ae7a89235", null ],
    [ "~XO_4x4_UI", "class_x_o__4x4___u_i.html#ac28d9e10c743ec07a0c5dbe9f78273d6", null ],
    [ "create_player", "class_x_o__4x4___u_i.html#a79351b29078354a4bb5a14d29568804e", null ],
    [ "get_move", "class_x_o__4x4___u_i.html#ac80d88983e2d8352c230d75f4e8a4cfd", null ]
];