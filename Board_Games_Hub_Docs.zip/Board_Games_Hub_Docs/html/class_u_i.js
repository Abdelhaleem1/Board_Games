var class_u_i =
[
    [ "UI", "class_u_i.html#afb59b53f3c2ed750b1a9a0c7d6dc4a7a", null ],
    [ "UI", "class_u_i.html#ae50eed41905ca2f8dc103d9bef427fe6", null ],
    [ "create_player", "class_u_i.html#a94561e0bb4bbcbe5ff71ca6d751922df", null ],
    [ "display_board_matrix", "class_u_i.html#aa3775124efaeac59935ae0afb354708d", null ],
    [ "display_message", "class_u_i.html#aaad19c26b8e4c49ba7ada54abd83e23c", null ],
    [ "get_move", "class_u_i.html#a8befa259c38c57e6ae2e8ed81c476337", null ],
    [ "get_player_name", "class_u_i.html#a7b1603de1f73fbb4006e4f00a27c44da", null ],
    [ "get_player_type_choice", "class_u_i.html#ac3d45fea2bbcaa0372d8e5101e116ca1", null ],
    [ "setup_players", "class_u_i.html#a6966a040c995b2292e5edddaa94f889a", null ],
    [ "cell_width", "class_u_i.html#a6c79c489ae9aa3a7860fb58e5a14ddfe", null ]
];