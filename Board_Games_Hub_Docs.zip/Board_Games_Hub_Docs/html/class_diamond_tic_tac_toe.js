var class_diamond_tic_tac_toe =
[
    [ "DiamondTicTacToe", "class_diamond_tic_tac_toe.html#a84cdd202295c7d6b8da8a9c394718985", null ],
    [ "~DiamondTicTacToe", "class_diamond_tic_tac_toe.html#a6163e4e6b01a05b1dacc965b136579bf", null ],
    [ "game_is_over", "class_diamond_tic_tac_toe.html#ac6e0b756c64ee411852941d24ec5af37", null ],
    [ "is_draw", "class_diamond_tic_tac_toe.html#a149462ea3fa58c804613faac95c4ac5a", null ],
    [ "is_lose", "class_diamond_tic_tac_toe.html#a78a73167084ee2e4cdacb2d39ac5ac8d", null ],
    [ "is_win", "class_diamond_tic_tac_toe.html#a39186ba5ecd7a72f0b768012a35c3ff7", null ],
    [ "update_board", "class_diamond_tic_tac_toe.html#a47ed18db7c29ac80e02e596adbc0c5f6", null ]
];