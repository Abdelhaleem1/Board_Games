var obs___tic_tac_toe_8h =
[
    [ "obs_TicTacToe_board", "classobs___tic_tac_toe__board.html", "classobs___tic_tac_toe__board" ],
    [ "obs_TicTacToe_UI", "classobs___tic_tac_toe___u_i.html", "classobs___tic_tac_toe___u_i" ]
];