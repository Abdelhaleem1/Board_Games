var class_tic_tac_toe__5x5___u_i =
[
    [ "TicTacToe_5x5_UI", "class_tic_tac_toe__5x5___u_i.html#af08a0c77bd4299db92dd0af029196052", null ],
    [ "~TicTacToe_5x5_UI", "class_tic_tac_toe__5x5___u_i.html#a7cafeccfad631c8515425e2c326d267b", null ],
    [ "create_player", "class_tic_tac_toe__5x5___u_i.html#aed306884fba975392b625265b21ad4a6", null ],
    [ "get_move", "class_tic_tac_toe__5x5___u_i.html#ac0386459e4d3d01add582dd86a5cdf8e", null ]
];