var class_diamond___u_i =
[
    [ "Diamond_UI", "class_diamond___u_i.html#ab324b9b8948308b1480ded25a7081e7a", null ],
    [ "~Diamond_UI", "class_diamond___u_i.html#ac8caa44a24baf3b834972ee0f054a060", null ],
    [ "display_board_matrix", "class_diamond___u_i.html#af3e111d85fd96e0ad0f0178f16742b37", null ],
    [ "get_move", "class_diamond___u_i.html#aff9b6acc0c3cc49a4877d33139d1776a", null ]
];