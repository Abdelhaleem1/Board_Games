var class_inf___x_o___u_i =
[
    [ "Inf_XO_UI", "class_inf___x_o___u_i.html#a94a5bedb151e870c9ccd78dfbf71696d", null ],
    [ "~Inf_XO_UI", "class_inf___x_o___u_i.html#a4917a1d5d8e0dcf1741c7ff14b26b2e7", null ],
    [ "create_player", "class_inf___x_o___u_i.html#a4bd24ecf6e6697927ac2351959598116", null ],
    [ "get_move", "class_inf___x_o___u_i.html#a6f893dc1d92e86427d442a427a038dd6", null ]
];