var class_tic_tac_toe__5x5__board =
[
    [ "TicTacToe_5x5_board", "class_tic_tac_toe__5x5__board.html#ae4eac29a358fd39dafec1d77fb1d1b62", null ],
    [ "consecutive_cells", "class_tic_tac_toe__5x5__board.html#a4f663fffc322fe84469594072990de64", null ],
    [ "game_is_over", "class_tic_tac_toe__5x5__board.html#a544fa70c79243448d7012346de05e5bf", null ],
    [ "is_draw", "class_tic_tac_toe__5x5__board.html#adaa7ca653df25d0507b9b9e7fbf443c9", null ],
    [ "is_lose", "class_tic_tac_toe__5x5__board.html#a68da689d9c1f5f284d075402c7d2233a", null ],
    [ "is_win", "class_tic_tac_toe__5x5__board.html#a803619469be8e947aa03fa5e25b51a34", null ],
    [ "update_board", "class_tic_tac_toe__5x5__board.html#ab5da218f35f78d35d2605c53c77107ca", null ]
];