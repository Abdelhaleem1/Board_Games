var searchData=
[
  ['random_5fobs_0',['random_obs',['../classobs___tic_tac_toe__board.html#a40ea9e5fa1f8b3d5b631e4ee9565cb4d',1,'obs_TicTacToe_board']]],
  ['rows_1',['rows',['../class_board.html#a948d978e3b5fc460559b588f5dee9572',1,'Board']]],
  ['run_2',['run',['../class_game_manager.html#a71f46d5189dac5c773f608cea1b5a203',1,'GameManager']]]
];
