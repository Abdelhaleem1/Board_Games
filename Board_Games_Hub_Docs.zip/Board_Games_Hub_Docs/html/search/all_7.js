var searchData=
[
  ['n_5fmoves_0',['n_moves',['../class_board.html#a5952baefabced65fecec333de638408d',1,'Board']]],
  ['name_1',['name',['../class_player.html#af0ad0d4ca8584d23a98c723cd703a4f6',1,'Player']]],
  ['numerical_5ftic_5ftac_5ftoe_2eh_2',['NUMERICAL_TIC_TAC_TOE.h',['../_n_u_m_e_r_i_c_a_l___t_i_c___t_a_c___t_o_e_8h.html',1,'']]],
  ['numerical_5fxo_5fboard_3',['Numerical_XO_Board',['../class_numerical___x_o___board.html',1,'Numerical_XO_Board'],['../class_numerical___x_o___board.html#a3a7b6956a9b0f96f28604286e11b8d72',1,'Numerical_XO_Board::Numerical_XO_Board()']]],
  ['numerical_5fxo_5fui_4',['Numerical_XO_UI',['../class_numerical___x_o___u_i.html',1,'Numerical_XO_UI'],['../class_numerical___x_o___u_i.html#a952961ac98f71c317b1f093f5c53a43d',1,'Numerical_XO_UI::Numerical_XO_UI()']]],
  ['nums_5',['nums',['../class_numerical___x_o___u_i.html#a2e489de2fd434173edadfa4c60e5e169',1,'Numerical_XO_UI']]]
];
