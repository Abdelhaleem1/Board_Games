var searchData=
[
  ['connect_5fboard_0',['CONNECT_Board',['../class_c_o_n_n_e_c_t___board.html',1,'']]],
  ['connect_5fui_1',['CONNECT_UI',['../class_c_o_n_n_e_c_t___u_i.html',1,'']]]
];
