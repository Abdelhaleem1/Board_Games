var searchData=
[
  ['inf_5ftictactoe_2eh_0',['Inf_TicTacToe.h',['../_inf___tic_tac_toe_8h.html',1,'']]],
  ['inverse_5fxo_5fui_2eh_1',['Inverse_XO_UI.h',['../_inverse___x_o___u_i_8h.html',1,'']]]
];
