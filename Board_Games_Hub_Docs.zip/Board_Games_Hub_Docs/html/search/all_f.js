var searchData=
[
  ['xo_5f4x4_5fboard_0',['XO_4x4_Board',['../class_x_o__4x4___board.html',1,'XO_4x4_Board'],['../class_x_o__4x4___board.html#a603d7ff46087b0f1704ed7ddd30165ac',1,'XO_4x4_Board::XO_4x4_Board()']]],
  ['xo_5f4x4_5fui_1',['XO_4x4_UI',['../class_x_o__4x4___u_i.html',1,'XO_4x4_UI'],['../class_x_o__4x4___u_i.html#ab9061a7ca8ebe5d55fb9f86ae7a89235',1,'XO_4x4_UI::XO_4x4_UI()']]]
];
