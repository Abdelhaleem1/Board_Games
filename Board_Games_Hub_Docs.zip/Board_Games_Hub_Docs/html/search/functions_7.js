var searchData=
[
  ['numerical_5fxo_5fboard_0',['Numerical_XO_Board',['../class_numerical___x_o___board.html#a3a7b6956a9b0f96f28604286e11b8d72',1,'Numerical_XO_Board']]],
  ['numerical_5fxo_5fui_1',['Numerical_XO_UI',['../class_numerical___x_o___u_i.html#a952961ac98f71c317b1f093f5c53a43d',1,'Numerical_XO_UI']]]
];
