var searchData=
[
  ['obs_5ftictactoe_5fboard_0',['obs_TicTacToe_board',['../classobs___tic_tac_toe__board.html',1,'']]],
  ['obs_5ftictactoe_5fui_1',['obs_TicTacToe_UI',['../classobs___tic_tac_toe___u_i.html',1,'']]]
];
