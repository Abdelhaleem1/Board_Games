var searchData=
[
  ['n_5fmoves_0',['n_moves',['../class_board.html#a5952baefabced65fecec333de638408d',1,'Board']]],
  ['name_1',['name',['../class_player.html#af0ad0d4ca8584d23a98c723cd703a4f6',1,'Player']]],
  ['nums_2',['nums',['../class_numerical___x_o___u_i.html#a2e489de2fd434173edadfa4c60e5e169',1,'Numerical_XO_UI']]]
];
