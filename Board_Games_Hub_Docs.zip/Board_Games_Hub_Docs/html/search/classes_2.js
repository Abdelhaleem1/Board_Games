var searchData=
[
  ['diamond_5fui_0',['Diamond_UI',['../class_diamond___u_i.html',1,'']]],
  ['diamondtictactoe_1',['DiamondTicTacToe',['../class_diamond_tic_tac_toe.html',1,'']]]
];
