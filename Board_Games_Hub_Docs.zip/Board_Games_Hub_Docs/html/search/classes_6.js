var searchData=
[
  ['numerical_5fxo_5fboard_0',['Numerical_XO_Board',['../class_numerical___x_o___board.html',1,'']]],
  ['numerical_5fxo_5fui_1',['Numerical_XO_UI',['../class_numerical___x_o___u_i.html',1,'']]]
];
