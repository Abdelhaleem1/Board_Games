var searchData=
[
  ['set_5fboard_5fptr_0',['set_board_ptr',['../class_player.html#a3617a3ad0db435176a06948065f9a3a6',1,'Player']]],
  ['setup_5fplayers_1',['setup_players',['../class_u_i.html#a6966a040c995b2292e5edddaa94f889a',1,'UI::setup_players()'],['../class_c_o_n_n_e_c_t___u_i.html#a351755f8befebd4627479821cf6a343f',1,'CONNECT_UI::setup_players()'],['../class_numerical___x_o___u_i.html#aafdcb392e23738e46198b87e54dbcfcc',1,'Numerical_XO_UI::setup_players()'],['../class_s_u_s___u_i.html#a24c1d67ea76050e7bee6159e9ba39aa2',1,'SUS_UI::setup_players()'],['../classword___x_o___u_i.html#a687dbd4b8f42c752c7c1343fe818be65',1,'word_XO_UI::setup_players()']]],
  ['sus_2eh_2',['SUS.h',['../_s_u_s_8h.html',1,'']]],
  ['sus_5fboard_3',['SUS_Board',['../class_s_u_s___board.html',1,'SUS_Board'],['../class_s_u_s___board.html#a653be0dfe8070a59361bd228c0b54f71',1,'SUS_Board::SUS_Board()']]],
  ['sus_5fui_4',['SUS_UI',['../class_s_u_s___u_i.html',1,'SUS_UI'],['../class_s_u_s___u_i.html#ac1a13d00ecf04b1ea3af53f1c08949c1',1,'SUS_UI::SUS_UI()']]],
  ['symbol_5',['symbol',['../class_player.html#a272d6c4dab769930d4f8074918e7708a',1,'Player']]]
];
