var class_pyramid___x_o___u_i =
[
    [ "Pyramid_XO_UI", "class_pyramid___x_o___u_i.html#af9b3ef5883c6499d39a77c222b0d2e03", null ],
    [ "~Pyramid_XO_UI", "class_pyramid___x_o___u_i.html#a6fa938bbc30ba3e9d6b9fa69adf5e891", null ],
    [ "create_player", "class_pyramid___x_o___u_i.html#ab7c835c5fbf86ec08d3262e840cd7563", null ],
    [ "display_board_matrix", "class_pyramid___x_o___u_i.html#a60d12fe999131b92d17996e6f99051e1", null ],
    [ "get_move", "class_pyramid___x_o___u_i.html#a9447abc21ff1b8baa5ac1d91d84b567e", null ]
];