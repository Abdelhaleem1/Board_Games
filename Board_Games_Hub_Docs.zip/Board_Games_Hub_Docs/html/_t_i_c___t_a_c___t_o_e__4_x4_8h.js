var _t_i_c___t_a_c___t_o_e__4_x4_8h =
[
    [ "XO_4x4_Board", "class_x_o__4x4___board.html", "class_x_o__4x4___board" ],
    [ "XO_4x4_UI", "class_x_o__4x4___u_i.html", "class_x_o__4x4___u_i" ]
];