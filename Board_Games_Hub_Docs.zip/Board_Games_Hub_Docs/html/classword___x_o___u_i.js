var classword___x_o___u_i =
[
    [ "word_XO_UI", "classword___x_o___u_i.html#af194e06b20ab92c209578e4d5f2f604c", null ],
    [ "~word_XO_UI", "classword___x_o___u_i.html#aab1b0edf4d47e1b38f0f85d99125fefb", null ],
    [ "create_player", "classword___x_o___u_i.html#a84796c2447c6a6706a1dc97665926441", null ],
    [ "get_move", "classword___x_o___u_i.html#a8ea7467296450e95f4cbdf78a654b519", null ],
    [ "setup_players", "classword___x_o___u_i.html#a687dbd4b8f42c752c7c1343fe818be65", null ]
];