var class_s_u_s___u_i =
[
    [ "SUS_UI", "class_s_u_s___u_i.html#ac1a13d00ecf04b1ea3af53f1c08949c1", null ],
    [ "~SUS_UI", "class_s_u_s___u_i.html#a5860425ff09d2e1971fb7822c69b1a34", null ],
    [ "create_player", "class_s_u_s___u_i.html#ae510c6c91efc4a17d7dadb4282e00e84", null ],
    [ "get_move", "class_s_u_s___u_i.html#a9c7a3c09a5e18a3d89f448ea93b6dea6", null ],
    [ "setup_players", "class_s_u_s___u_i.html#a24c1d67ea76050e7bee6159e9ba39aa2", null ]
];