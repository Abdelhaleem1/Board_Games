var class_memory___u_i =
[
    [ "Memory_UI", "class_memory___u_i.html#a86e9d67bbb016aa6b49a61d4401d8ae4", null ],
    [ "~Memory_UI", "class_memory___u_i.html#a9081a7ca8792bf1f888951beea19b65a", null ],
    [ "create_player", "class_memory___u_i.html#a056bb62e0e737269c29383c94e48e58a", null ],
    [ "display_board_matrix", "class_memory___u_i.html#a9ca7376cbc620472390f3b75a474a1d8", null ],
    [ "get_move", "class_memory___u_i.html#a3e27165bf43524664d5bcd76e52910cb", null ]
];