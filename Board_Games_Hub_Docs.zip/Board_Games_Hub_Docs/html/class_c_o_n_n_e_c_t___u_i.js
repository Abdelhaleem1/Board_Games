var class_c_o_n_n_e_c_t___u_i =
[
    [ "CONNECT_UI", "class_c_o_n_n_e_c_t___u_i.html#a9f75efd5907f7eb6577b576fc40e7233", null ],
    [ "~CONNECT_UI", "class_c_o_n_n_e_c_t___u_i.html#a349f71f973f1a073ef3acc5389718e2a", null ],
    [ "create_player", "class_c_o_n_n_e_c_t___u_i.html#a2d0cf566c8c93fb0af0bede76d262e38", null ],
    [ "get_move", "class_c_o_n_n_e_c_t___u_i.html#ac7ff3ba75db7f1655fcb35e02d8b4206", null ],
    [ "setup_players", "class_c_o_n_n_e_c_t___u_i.html#a351755f8befebd4627479821cf6a343f", null ]
];