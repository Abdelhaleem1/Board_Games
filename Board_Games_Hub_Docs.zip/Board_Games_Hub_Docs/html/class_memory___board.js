var class_memory___board =
[
    [ "Memory_Board", "class_memory___board.html#a235743f1bdf5051526c92cc59b276340", null ],
    [ "game_is_over", "class_memory___board.html#ad806fdf49150705c3f4892e74e8dedc4", null ],
    [ "is_draw", "class_memory___board.html#ad80149de055f8902191f1124d23619df", null ],
    [ "is_lose", "class_memory___board.html#a0c40062fe9f07b532ad893747d5d47e5", null ],
    [ "is_win", "class_memory___board.html#a8ebd3f4825d7a3ac78cc77ef85738de9", null ],
    [ "update_board", "class_memory___board.html#acd27c6b472578e92edeb9f662a3af580", null ]
];