var class_ultimate___u_i =
[
    [ "Ultimate_UI", "class_ultimate___u_i.html#a9e3b3b9207e382ffc43d8e34bcb34ce0", null ],
    [ "~Ultimate_UI", "class_ultimate___u_i.html#a5bcb2283b1c7636b883c1c18dc9fcb68", null ],
    [ "display_board_matrix", "class_ultimate___u_i.html#af6f74c26396738910a9dea743634be07", null ],
    [ "get_move", "class_ultimate___u_i.html#a4c3e6b4f77e281d67a946df1620ef822", null ]
];