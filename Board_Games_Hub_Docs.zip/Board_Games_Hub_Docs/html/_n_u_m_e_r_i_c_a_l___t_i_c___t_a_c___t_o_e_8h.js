var _n_u_m_e_r_i_c_a_l___t_i_c___t_a_c___t_o_e_8h =
[
    [ "Numerical_XO_Board", "class_numerical___x_o___board.html", "class_numerical___x_o___board" ],
    [ "Numerical_XO_UI", "class_numerical___x_o___u_i.html", "class_numerical___x_o___u_i" ]
];