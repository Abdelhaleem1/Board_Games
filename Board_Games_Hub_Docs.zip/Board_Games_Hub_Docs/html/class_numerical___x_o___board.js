var class_numerical___x_o___board =
[
    [ "Numerical_XO_Board", "class_numerical___x_o___board.html#a3a7b6956a9b0f96f28604286e11b8d72", null ],
    [ "game_is_over", "class_numerical___x_o___board.html#aea865c12dbbcd3bd501ca99b6f0c80e9", null ],
    [ "is_draw", "class_numerical___x_o___board.html#a7f0aef8542ff7e8159affa5ae315e5f8", null ],
    [ "is_lose", "class_numerical___x_o___board.html#a74900bbfe712620b87ec3648528debbe", null ],
    [ "is_win", "class_numerical___x_o___board.html#aac67dc4ca334d86622e5653c9316861f", null ],
    [ "update_board", "class_numerical___x_o___board.html#adf427b7be994d6c6c24793aba6a6ce44", null ]
];