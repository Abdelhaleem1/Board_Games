var class_inverse___x_o___u_i =
[
    [ "Inverse_XO_UI", "class_inverse___x_o___u_i.html#a7de03b80ef99e68967ef3b6a8bb80b7f", null ],
    [ "~Inverse_XO_UI", "class_inverse___x_o___u_i.html#a104f12ec3f5c7dc2cac402b6f630d15d", null ],
    [ "create_player", "class_inverse___x_o___u_i.html#a61aac02bac8cc42b5e7ae3e88d4db425", null ],
    [ "get_move", "class_inverse___x_o___u_i.html#a6794c4c9f1190b6fddeeb321e678ee4d", null ]
];