var class_c_o_n_n_e_c_t___board =
[
    [ "CONNECT_Board", "class_c_o_n_n_e_c_t___board.html#ae8f35e4649f8820279f202a12b3ba856", null ],
    [ "game_is_over", "class_c_o_n_n_e_c_t___board.html#ada74ecec1cfdc3c8269ecda8ffa964c0", null ],
    [ "is_draw", "class_c_o_n_n_e_c_t___board.html#a9bb847bf44bd42dc1ed6af025b3a1320", null ],
    [ "is_lose", "class_c_o_n_n_e_c_t___board.html#a0226660b37c9f7a4fba1bbd291b2df0a", null ],
    [ "is_win", "class_c_o_n_n_e_c_t___board.html#a7f74a73350866a9abd36c360087d902c", null ],
    [ "update_board", "class_c_o_n_n_e_c_t___board.html#a0717261b7ba6d142fa0c8c876e2d6daa", null ]
];