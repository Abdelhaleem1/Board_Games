var class_s_u_s___board =
[
    [ "SUS_Board", "class_s_u_s___board.html#a653be0dfe8070a59361bd228c0b54f71", null ],
    [ "condition", "class_s_u_s___board.html#a54a201964cf32c3f6db30ffa82fb7aea", null ],
    [ "game_is_over", "class_s_u_s___board.html#acd2c39612239065da3aea67ac7c27aa4", null ],
    [ "is_draw", "class_s_u_s___board.html#aeb2ad5ce9bdd10ecf2d3cf06be14e6ca", null ],
    [ "is_lose", "class_s_u_s___board.html#a3761b3ce05e2194ff95893b494a3c933", null ],
    [ "is_win", "class_s_u_s___board.html#a2230a0e70a119a14e7e7380ba9b2cb90", null ],
    [ "update_board", "class_s_u_s___board.html#af360d853f6d48c2bcaabdd7e2629e7ff", null ]
];