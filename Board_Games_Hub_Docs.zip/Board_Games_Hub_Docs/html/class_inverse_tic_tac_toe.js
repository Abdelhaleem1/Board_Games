var class_inverse_tic_tac_toe =
[
    [ "InverseTicTacToe", "class_inverse_tic_tac_toe.html#af0001861fd578f356232f48696e158ea", null ],
    [ "~InverseTicTacToe", "class_inverse_tic_tac_toe.html#a203b8536e93c1af71523a8fd2a997a08", null ],
    [ "game_is_over", "class_inverse_tic_tac_toe.html#a5c2753d2dae29a53b51471adadcd8a6e", null ],
    [ "is_draw", "class_inverse_tic_tac_toe.html#aed9032707d6d8332829e1f4289cc22bf", null ],
    [ "is_lose", "class_inverse_tic_tac_toe.html#a66f7905d948a3da5f93a872fc8d91c09", null ],
    [ "is_win", "class_inverse_tic_tac_toe.html#a0a488706b36b148af16ee7ceae0c2953", null ],
    [ "update_board", "class_inverse_tic_tac_toe.html#ac93fd915517731a94797107be985b68c", null ]
];