var hierarchy =
[
    [ "Board&lt; T &gt;", "class_board.html", [
      [ "DiamondTicTacToe< T >", "class_diamond_tic_tac_toe.html", null ],
      [ "InverseTicTacToe< T >", "class_inverse_tic_tac_toe.html", null ],
      [ "UltimateTicTacToe< T >", "class_ultimate_tic_tac_toe.html", null ]
    ] ],
    [ "Board&lt; char &gt;", "class_board.html", [
      [ "CONNECT_Board", "class_c_o_n_n_e_c_t___board.html", null ],
      [ "Inf_XO_Board", "class_inf___x_o___board.html", null ],
      [ "Memory_Board", "class_memory___board.html", null ],
      [ "Numerical_XO_Board", "class_numerical___x_o___board.html", null ],
      [ "Pyramid_XO_Board", "class_pyramid___x_o___board.html", null ],
      [ "SUS_Board", "class_s_u_s___board.html", null ],
      [ "TicTacToe_5x5_board", "class_tic_tac_toe__5x5__board.html", null ],
      [ "XO_4x4_Board", "class_x_o__4x4___board.html", null ],
      [ "obs_TicTacToe_board", "classobs___tic_tac_toe__board.html", null ],
      [ "word_XO_Board", "classword___x_o___board.html", null ]
    ] ],
    [ "GameManager&lt; T &gt;", "class_game_manager.html", null ],
    [ "Move&lt; T &gt;", "class_move.html", null ],
    [ "Player&lt; T &gt;", "class_player.html", null ],
    [ "UI&lt; T &gt;", "class_u_i.html", null ],
    [ "UI&lt; char &gt;", "class_u_i.html", [
      [ "CONNECT_UI", "class_c_o_n_n_e_c_t___u_i.html", null ],
      [ "Diamond_UI", "class_diamond___u_i.html", null ],
      [ "Inf_XO_UI", "class_inf___x_o___u_i.html", null ],
      [ "Inverse_XO_UI", "class_inverse___x_o___u_i.html", null ],
      [ "Memory_UI", "class_memory___u_i.html", null ],
      [ "Numerical_XO_UI", "class_numerical___x_o___u_i.html", null ],
      [ "Pyramid_XO_UI", "class_pyramid___x_o___u_i.html", null ],
      [ "SUS_UI", "class_s_u_s___u_i.html", null ],
      [ "TicTacToe_5x5_UI", "class_tic_tac_toe__5x5___u_i.html", null ],
      [ "Ultimate_UI", "class_ultimate___u_i.html", null ],
      [ "XO_4x4_UI", "class_x_o__4x4___u_i.html", null ],
      [ "obs_TicTacToe_UI", "classobs___tic_tac_toe___u_i.html", null ],
      [ "word_XO_UI", "classword___x_o___u_i.html", null ]
    ] ]
];