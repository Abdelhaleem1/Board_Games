var class_numerical___x_o___u_i =
[
    [ "Numerical_XO_UI", "class_numerical___x_o___u_i.html#a952961ac98f71c317b1f093f5c53a43d", null ],
    [ "~Numerical_XO_UI", "class_numerical___x_o___u_i.html#a381a99a2533c553c34301689760a3ce7", null ],
    [ "create_player", "class_numerical___x_o___u_i.html#ad76a74171761d4b8e47dbb0dd573adce", null ],
    [ "get_move", "class_numerical___x_o___u_i.html#af6296ae59c604456f531f4e996e99467", null ],
    [ "setup_players", "class_numerical___x_o___u_i.html#aafdcb392e23738e46198b87e54dbcfcc", null ],
    [ "nums", "class_numerical___x_o___u_i.html#a2e489de2fd434173edadfa4c60e5e169", null ]
];