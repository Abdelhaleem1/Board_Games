var class_inf___x_o___board =
[
    [ "Inf_XO_Board", "class_inf___x_o___board.html#a16bf9d5af2efc635a40743e1af8f848f", null ],
    [ "game_is_over", "class_inf___x_o___board.html#a74102372222ea1d8a3554f6416470f05", null ],
    [ "is_draw", "class_inf___x_o___board.html#aa33eab7f6e53ab256e0e52399e46b34e", null ],
    [ "is_lose", "class_inf___x_o___board.html#a00f2f9bfd168a7142d1622d09ccad7ed", null ],
    [ "is_win", "class_inf___x_o___board.html#ad4578f37f0106106347f135dc1f0b59b", null ],
    [ "isFull", "class_inf___x_o___board.html#aa519b6316a61da2ecf08b8752f9d8dbb", null ],
    [ "update_board", "class_inf___x_o___board.html#a252c966b8b44b932f71813ab1803106e", null ]
];