var class_x_o__4x4___board =
[
    [ "XO_4x4_Board", "class_x_o__4x4___board.html#a603d7ff46087b0f1704ed7ddd30165ac", null ],
    [ "game_is_over", "class_x_o__4x4___board.html#a0db1bbadc3786d7d81a9acc69bc5e6e8", null ],
    [ "is_draw", "class_x_o__4x4___board.html#ae2d1a15fb3fdd8e2431b59337743736d", null ],
    [ "is_lose", "class_x_o__4x4___board.html#aa39280fb193275462ae5c387dcb8c6ed", null ],
    [ "is_win", "class_x_o__4x4___board.html#a112ca743e40e4dd5c54722408712e1f6", null ],
    [ "update_board", "class_x_o__4x4___board.html#aed5461909a9bf600265e6caa97537885", null ]
];