var classobs___tic_tac_toe___u_i =
[
    [ "obs_TicTacToe_UI", "classobs___tic_tac_toe___u_i.html#a23d8daf89245fd463efb64cd3efefbd6", null ],
    [ "~obs_TicTacToe_UI", "classobs___tic_tac_toe___u_i.html#a835ab638922e0702d2c6e72f25070686", null ],
    [ "create_player", "classobs___tic_tac_toe___u_i.html#a63ad6f6d2ec6fe839f1903b289e6e1cb", null ],
    [ "get_move", "classobs___tic_tac_toe___u_i.html#aa329ed51ccb5eb639872b6dc0975ccf2", null ]
];