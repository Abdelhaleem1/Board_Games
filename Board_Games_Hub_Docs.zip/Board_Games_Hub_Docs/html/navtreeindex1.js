var NAVTREEINDEX1 =
{
"functions.html":[0,3,0],
"functions_func.html":[0,3,1],
"functions_vars.html":[0,3,2],
"globals.html":[1,1,0],
"globals_func.html":[1,1,1],
"hierarchy.html":[0,2],
"index.html":[],
"main_8cpp.html":[1,0,7],
"main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4":[1,0,7,0],
"obs___tic_tac_toe_8h.html":[1,0,10],
"obs___tic_tac_toe_8h_source.html":[1,0,10],
"pages.html":[]
};
