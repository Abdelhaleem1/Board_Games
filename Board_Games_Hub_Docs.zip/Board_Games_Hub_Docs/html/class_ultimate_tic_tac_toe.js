var class_ultimate_tic_tac_toe =
[
    [ "UltimateTicTacToe", "class_ultimate_tic_tac_toe.html#a4b671a1164ec956b28c14e4f825be2ae", null ],
    [ "~UltimateTicTacToe", "class_ultimate_tic_tac_toe.html#a8230337d4728ad3da953b618bb9f6f08", null ],
    [ "game_is_over", "class_ultimate_tic_tac_toe.html#a68eabf072d0700a7fd70deb9eed1ca00", null ],
    [ "is_draw", "class_ultimate_tic_tac_toe.html#a684dd427e415e965296348ee1fedb812", null ],
    [ "is_lose", "class_ultimate_tic_tac_toe.html#a7c082e9cfb77b64c256757ac7c3a2d3e", null ],
    [ "is_win", "class_ultimate_tic_tac_toe.html#a2c122cc8f265a71b874c38675c626465", null ],
    [ "update_board", "class_ultimate_tic_tac_toe.html#ad9a5d95143ed8f90a84e0c8183709261", null ]
];